import { useEffect, useState } from "react";
import { Container } from "react-bootstrap";
import { useParams, useNavigate } from "react-router-dom";
import Aos from "aos";
import "aos/dist/aos.css";
import axios from "axios";
import { IoLogoWhatsapp } from "react-icons/io";
import { FaTrophy, FaArrowLeft, FaMedal } from "react-icons/fa";
import { GiShuttlecock } from "react-icons/gi";
import { HiTrendingUp, HiTrendingDown, HiMinus } from "react-icons/hi";
import "../Styles/ranking.css";

const RankingDetail = () => {
  const { year, category } = useParams();
  const navigate            = useNavigate();
  const decodedCat          = decodeURIComponent(category);

  const [players,       setPlayers]       = useState([]);
  const [tourneyLabels, setTourneyLabels] = useState([]);
  const [groupTitle,    setGroupTitle]    = useState("");
  const [loading,       setLoading]       = useState(true);
  const [search,        setSearch]        = useState("");

  useEffect(() => {
    Aos.init({ once: true });
    window.scroll(0, 0);
    fetchAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [year, category]);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [rankRes, groupRes] = await Promise.all([
        axios.get(`${process.env.REACT_APP_API_URL}/api/admin/activerankings?year=${year}`),
        axios.get(`${process.env.REACT_APP_API_URL}/api/admin/activerankinggroups`),
      ]);

      const grouped = rankRes?.data?.rankings || {};
      const list    = Array.isArray(grouped[decodedCat]) ? grouped[decodedCat] : [];
      const sorted  = list.slice().sort((a, b) => Number(a.Rank) - Number(b.Rank));
      setPlayers(sorted);

      const groups     = Array.isArray(groupRes?.data?.groups) ? groupRes.data.groups : [];
      const matchGroup = groups.find(
        (g) => String(g.Year) === String(year) && g.Category === decodedCat
      );

      if (matchGroup) setGroupTitle(matchGroup.Title || "");

      const savedLabels = matchGroup?.TournamentLabels?.length > 0
        ? matchGroup.TournamentLabels : null;

      if (savedLabels) {
        setTourneyLabels(savedLabels);
      } else {
        const maxT = Math.max(...sorted.map((p) =>
          Array.isArray(p.tournamentPoints) ? p.tournamentPoints.length : 0
        ), 0);
        setTourneyLabels(Array.from({ length: maxT }, (_, i) => `Tournament ${i + 1}`));
      }
    } catch {
      setPlayers([]);
      setTourneyLabels([]);
    } finally {
      setLoading(false);
    }
  };

  const filtered = players.filter((p) =>
    !search ||
    [p.PlayerName, p.Club, p.City, p.State]
      .filter(Boolean)
      .some((v) => v.toLowerCase().includes(search.toLowerCase()))
  );

  const numT = tourneyLabels.length;

  const Trend = ({ current, previous }) => {
    const c = Number(current); const p = Number(previous);
    if (!p || p === c) return <span className="rk-trend neutral"><HiMinus /></span>;
    if (c < p) return <span className="rk-trend up"><HiTrendingUp />{p - c}</span>;
    return <span className="rk-trend down"><HiTrendingDown />{c - p}</span>;
  };

  const medalColor = (rank) => {
    if (rank === 1) return "#B8860B";
    if (rank === 2) return "#607080";
    if (rank === 3) return "#8B5A2B";
    return "#031b77";
  };

  return (
    <div className="rk-detail-page">

      {/* Floating WhatsApp */}
      <div className="fixed-icon">
        <a href="https://wa.link/5s5pya" target="_blank" rel="noopener noreferrer"
          style={{ color:"unset", textDecoration:"none" }}>
          <span className="fixed-icon-rings" />
          <IoLogoWhatsapp style={{ color:"white", fontSize:"34px",
            display:"block", position:"relative", zIndex:4 }} />
        </a>
      </div>

      {/* ── Hero Banner ───────────────────── */}
      <div className="rk-detail-hero">
        <img src="../Assets/eventbg1.jpg" alt="Ranking" className="rk-detail-hero-bg" />
        <div className="rk-detail-hero-overlay" />
        <div className="rk-detail-hero-content" data-aos="fade-down" data-aos-duration="700">
          <p className="rk-detail-eyebrow">
            <GiShuttlecock /> SHUTTLE SMASH RANKING CIRCUIT
          </p>
          <h1 className="rk-detail-title">
            {year} <span className="rk-detail-dash">—</span> {decodedCat}
          </h1>
          {!loading && players.length > 0 && (
            <div className="rk-detail-stats">
              <div className="rk-detail-stat">
                <strong>{players.length}</strong>
                <span>Players</span>
              </div>
              <div className="rk-detail-stat-sep" />
              <div className="rk-detail-stat">
                <strong>{numT || "—"}</strong>
                <span>Tournaments</span>
              </div>
              <div className="rk-detail-stat-sep" />
              <div className="rk-detail-stat">
                <strong>
                  {players[0]?.Points
                    ? Number(players[0].Points).toLocaleString()
                    : "—"}
                </strong>
                <span>Top Score</span>
              </div>
            </div>
          )}
        </div>
        <button className="rk-detail-back" onClick={() => navigate("/ranking")}>
          <FaArrowLeft /> Back to Rankings
        </button>
      </div>

      {/* ── Content ───────────────────────── */}
      <Container fluid style={{ paddingLeft: 24, paddingRight: 24 }}>

        {loading && (
          <div className="rk-center-state">
            <GiShuttlecock className="rk-spin-icon" />
            <p>Loading rankings…</p>
          </div>
        )}

        {!loading && players.length === 0 && (
          <div className="rk-center-state">
            <FaTrophy style={{ fontSize:52, color:"#e0e4f0", display:"block", margin:"0 auto 16px" }} />
            <p>No players ranked yet in this category.</p>
            <button className="rk-back-pill" onClick={() => navigate("/ranking")}>
              <FaArrowLeft /> Back to Rankings
            </button>
          </div>
        )}

        {!loading && players.length > 0 && (
          <div className="rk-leaderboard-section" data-aos="fade-up" data-aos-duration="700">

            {/* ── Leaderboard header ──────── */}
            <div className="rk-lb-header">
              <div className="rk-lb-header-left">
                <div className="rk-lb-badge">
                  <FaTrophy />
                </div>
                <div>
                  <div className="rk-lb-title">
                    {groupTitle || `${year} — ${decodedCat}`}
                  </div>
                  <div className="rk-lb-subtitle">
                    {decodedCat} LEADERBOARD &nbsp;·&nbsp; {year}
                  </div>
                  <div className="rk-lb-note">
                    Points are added to players' profile after every tournament
                  </div>
                </div>
              </div>
              <div className="rk-lb-search-wrap">
                <input
                  type="text"
                  className="rk-lb-search"
                  placeholder="🔍  Search player, club or city…"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
                <span className="rk-lb-count">{filtered.length} players</span>
              </div>
            </div>

            {/* ── The leaderboard table ────── */}
            <div className="rk-lb-table-wrap">
              <table className="rk-lb-table">
                <thead>
                  <tr className="rk-lb-thead-row">
                    {/* fixed cols */}
                    <th className="rk-lbt-rank">Final Rank</th>
                    <th className="rk-lbt-name">Name</th>
                    <th className="rk-lbt-club">Club / City</th>
                    <th className="rk-lbt-state">State</th>
                    {/* tournament cols */}
                    {tourneyLabels.map((lbl, i) => (
                      <th key={i} className="rk-lbt-t">{lbl}</th>
                    ))}
                    {/* total */}
                    <th className="rk-lbt-total">Total Points</th>
                    {/* change */}
                    <th className="rk-lbt-change">Change</th>
                  </tr>
                </thead>
                <tbody>
                  {filtered.length === 0 ? (
                    <tr>
                      <td colSpan={5 + numT} className="rk-lb-empty">
                        No players match "{search}"
                      </td>
                    </tr>
                  ) : filtered.map((player, i) => {
                    const rank    = Number(player.Rank);
                    const tpts    = Array.isArray(player.tournamentPoints)
                      ? player.tournamentPoints : [];
                    const isTop3  = rank <= 3;
                    const initial = (player.PlayerName || "?").trim().charAt(0).toUpperCase();

                    return (
                      <tr key={player._id}
                        className={`rk-lb-row${isTop3 ? " rk-lb-top3" : ""}${i % 2 === 1 ? " rk-lb-alt" : ""}`}
                        data-aos="fade-up" data-aos-duration="350"
                        data-aos-delay={Math.min(i * 20, 300)}>

                        {/* Final Rank */}
                        <td className="rk-lbd-rank">
                          <div className="rk-rank-wrap">
                            {isTop3 && (
                              rank === 1 ? <FaTrophy className="rk-rank-icon gold" />
                              : rank === 2 ? <FaMedal className="rk-rank-icon silver" />
                              : <FaMedal className="rk-rank-icon bronze" />
                            )}
                            <span className="rk-rank-num"
                              style={{ color: isTop3 ? medalColor(rank) : "#031b77" }}>
                              {rank}
                            </span>
                          </div>
                        </td>

                        {/* Name */}
                        <td className="rk-lbd-name">
                          <div className="rk-name-wrap">
                            {player.PlayerImage ? (
                              <img
                                src={`${process.env.REACT_APP_API_URL}/Rankings/${player.PlayerImage}`}
                                alt={player.PlayerName} className="rk-lb-avatar" />
                            ) : (
                              <div className="rk-lb-avatar-ph"
                                style={{
                                  background: rank === 1
                                    ? "linear-gradient(135deg,#FFF3A3,#FFD700)"
                                    : rank === 2
                                    ? "linear-gradient(135deg,#E8EEF5,#B0C4D8)"
                                    : rank === 3
                                    ? "linear-gradient(135deg,#F5E6D0,#D4956A)"
                                    : "linear-gradient(135deg,#EEF2FF,#C7D7F5)",
                                }}>
                                {initial}
                              </div>
                            )}
                            <span className="rk-lb-name">{player.PlayerName}</span>
                          </div>
                        </td>

                        {/* Club */}
                        <td className="rk-lbd-club">
                          {[player.Club, player.City].filter(Boolean).join(", ") || "—"}
                        </td>

                        {/* State */}
                        <td className="rk-lbd-state">{player.State || "—"}</td>

                        {/* Per-tournament points */}
                        {tourneyLabels.map((_, ti) => (
                          <td key={ti} className="rk-lbd-t">
                            {tpts[ti] > 0
                              ? <span className="rk-t-score">{tpts[ti]}</span>
                              : <span className="rk-t-empty">—</span>}
                          </td>
                        ))}

                        {/* Total */}
                        <td className="rk-lbd-total">
                          <span className="rk-total-score"
                            style={{
                              background: rank === 1 ? "#FFD700"
                                : rank === 2 ? "#94A3B8"
                                : rank === 3 ? "#CD7F32"
                                : "#031b77",
                              color: rank <= 3 ? "#222" : "#fff",
                            }}>
                            {Number(player.Points || 0).toLocaleString()}
                          </span>
                        </td>

                        {/* Change */}
                        <td className="rk-lbd-change">
                          <Trend current={player.Rank} previous={player.PreviousRank} />
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

          </div>
        )}
      </Container>
    </div>
  );
};

export default RankingDetail;
