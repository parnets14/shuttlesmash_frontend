import React, { useState, useEffect, useCallback } from "react";
import { Button, Modal, Form, Image } from "react-bootstrap";
import { AiFillDelete } from "react-icons/ai";
import { BiSolidEdit } from "react-icons/bi";
import {
  FaPlus, FaTrophy, FaChevronDown, FaChevronUp,
  FaUsers, FaSave, FaUserPlus, FaMedal,
} from "react-icons/fa";
import { MdAutoAwesome } from "react-icons/md";
import axios from "axios";
import "../Admin/Admin.css";
import "./AdminRanking.css";

/* ── constants ──────────────────────────────── */
const CATEGORIES = [
  "Corporate","Men's Singles","Women's Singles",
  "Men's Doubles","Women's Doubles","Mixed Doubles",
  "Junior","Boys U15 Singles","Girls U15 Singles",
  "Boys U19 Singles","Girls U19 Singles",
];
const thisYear = new Date().getFullYear();
const YEARS    = Array.from({ length: 6 }, (_, i) => thisYear - i);
const safe     = (v) => (Array.isArray(v) ? v : []);

/* blank player row */
const blankRow = (id) => ({
  _tmpId:           id,
  PlayerName:       "",
  Club:             "",
  City:             "",
  State:            "",
  TournamentsPlayed: 0,
  tournamentPoints: [0],   // array of per-tournament points
  Points:           0,     // auto-calculated total
  Rank:             0,     // auto-calculated
  PreviousRank:     0,
  Status:           "Active",
  _saved:           false,
  _dbId:            null,
});

let tmpCounter = 1;

/* ════════════════════════════════════════════════
   MAIN COMPONENT
   ════════════════════════════════════════════════ */
const AdminRanking = () => {

  /* ── groups ─────────────────────────────────── */
  const [groups,     setGroups]     = useState([]);
  const [expandedId, setExpandedId] = useState(null);

  /* ── group form ──────────────────────────────── */
  const [showGroupAdd,  setShowGroupAdd]  = useState(false);
  const [showGroupEdit, setShowGroupEdit] = useState(false);
  const [showGroupDel,  setShowGroupDel]  = useState(false);
  const [gTitle,    setGTitle]    = useState("");
  const [gTagline,  setGTagline]  = useState("Turn your childhood dream into reality");
  const [gYear,     setGYear]     = useState(thisYear);
  const [gCategory, setGCategory] = useState(CATEGORIES[0]);
  const [gImage,    setGImage]    = useState(null);
  const [gStatus,   setGStatus]   = useState("Active");
  const [gEditItem, setGEditItem] = useState(null);
  const [gDelId,    setGDelId]    = useState("");

  /* ── grid state (per group) ──────────────────── */
  // gridData[groupId] = { rows: [...], numTournaments: N, tournamentLabels: [...] }
  const [gridData,    setGridData]    = useState({});
  const [gridLoading, setGridLoading] = useState({});  // { [groupId]: bool }
  const [saving,      setSaving]      = useState(false);
  const [showDelRow,  setShowDelRow]  = useState(false);
  const [delRowInfo,  setDelRowInfo]  = useState(null); // { groupId, tmpId, dbId }

  /* ════ helpers ══════════════════════════════ */
  const recalculate = (rows) => {
    // 1. sum points for each row
    const withTotals = rows.map((r) => ({
      ...r,
      Points: safe(r.tournamentPoints).reduce((s, v) => s + (Number(v) || 0), 0),
      TournamentsPlayed: safe(r.tournamentPoints).filter((v) => Number(v) > 0).length,
    }));
    // 2. sort by points desc, assign rank
    const sorted = [...withTotals].sort((a, b) => b.Points - a.Points);
    const ranked = withTotals.map((r) => ({
      ...r,
      Rank: sorted.findIndex((s) => s._tmpId === r._tmpId) + 1,
    }));
    return ranked;
  };

  const getGrid = (groupId) =>
    gridData[groupId] || { rows: [], numTournaments: 1, tournamentLabels: ["T1"] };

  const setGrid = (groupId, updater) => {
    setGridData((prev) => {
      const cur = prev[groupId] || { rows: [], numTournaments: 1, tournamentLabels: ["T1"] };
      const next = typeof updater === "function" ? updater(cur) : updater;
      return { ...prev, [groupId]: next };
    });
  };

  /* ════ fetch groups ══════════════════════════ */
  const fetchGroups = async () => {
    try {
      const res = await axios.get(`${process.env.REACT_APP_API_URL}/api/admin/getrankinggroups`);
      setGroups(safe(res?.data?.groups));
    } catch { setGroups([]); }
  };
  useEffect(() => { fetchGroups(); }, []);

  /* ════ load existing players into grid ══════ */
  const loadPlayersIntoGrid = async (group) => {
    setGridLoading((prev) => ({ ...prev, [group._id]: true }));
    try {
      const res = await axios.get(`${process.env.REACT_APP_API_URL}/api/admin/getrankings`);
      const all  = safe(res?.data?.getRankings);
      const mine = all
        .filter((p) => String(p.Year) === String(group.Year) && p.Category === group.Category)
        .sort((a, b) => Number(a.Rank) - Number(b.Rank));

      // use saved labels from group, or derive from data
      const savedLabels = Array.isArray(group.TournamentLabels) && group.TournamentLabels.length > 0
        ? group.TournamentLabels
        : null;

      if (mine.length === 0) {
        const defaultLabels = savedLabels || ["T1"];
        setGrid(group._id, {
          rows: [blankRow(tmpCounter++), blankRow(tmpCounter++), blankRow(tmpCounter++)].map(r => ({
            ...r, tournamentPoints: Array(defaultLabels.length).fill(0)
          })),
          numTournaments: defaultLabels.length,
          tournamentLabels: defaultLabels,
        });
        return;
      }

      const maxT = Math.max(...mine.map((p) =>
        Array.isArray(p.tournamentPoints) ? p.tournamentPoints.length : 1
      ), 1);

      const finalLabels = savedLabels && savedLabels.length >= maxT
        ? savedLabels.slice(0, maxT)
        : Array.from({ length: maxT }, (_, i) =>
            savedLabels && savedLabels[i] ? savedLabels[i] : `T${i + 1}`
          );

      const rows = mine.map((p) => {
        const tpts = Array.isArray(p.tournamentPoints)
          ? [...p.tournamentPoints, ...Array(maxT - p.tournamentPoints.length).fill(0)]
          : [p.Points, ...Array(maxT - 1).fill(0)];
        return {
          _tmpId:           tmpCounter++,
          PlayerName:       p.PlayerName       || "",
          Club:             p.Club             || "",
          City:             p.City             || "",
          State:            p.State            || "",
          TournamentsPlayed: p.TournamentsPlayed || 0,
          tournamentPoints: tpts,
          Points:           p.Points           || 0,
          Rank:             Number(p.Rank)      || 0,
          PreviousRank:     p.PreviousRank      || 0,
          Status:           p.Status           || "Active",
          _saved:           true,
          _dbId:            p._id,
        };
      });

      setGrid(group._id, {
        rows: recalculate(rows),
        numTournaments: maxT,
        tournamentLabels: finalLabels,
      });
    } catch {
      setGrid(group._id, {
        rows: [blankRow(tmpCounter++), blankRow(tmpCounter++), blankRow(tmpCounter++)],
        numTournaments: 1,
        tournamentLabels: ["T1"],
      });
    } finally {
      setGridLoading((prev) => ({ ...prev, [group._id]: false }));
    }
  };

  /* ════ toggle accordion ══════════════════════ */
  const toggleExpand = (group) => {
    if (expandedId === group._id) { setExpandedId(null); return; }
    setExpandedId(group._id);
    loadPlayersIntoGrid(group);
  };

  /* ════ grid cell edit ════════════════════════ */
  const updateCell = (groupId, tmpId, field, value) => {
    setGrid(groupId, (cur) => {
      const rows = cur.rows.map((r) => {
        if (r._tmpId !== tmpId) return r;
        return { ...r, [field]: value, _saved: false };
      });
      return { ...cur, rows: recalculate(rows) };
    });
  };

  const updateTournamentPoint = (groupId, tmpId, tIdx, value) => {
    setGrid(groupId, (cur) => {
      const rows = cur.rows.map((r) => {
        if (r._tmpId !== tmpId) return r;
        const tpts = [...r.tournamentPoints];
        tpts[tIdx] = Number(value) || 0;
        return { ...r, tournamentPoints: tpts, _saved: false };
      });
      return { ...cur, rows: recalculate(rows) };
    });
  };

  /* ════ add / remove tournament column ═══════ */
  const addTournament = (groupId) => {
    setGrid(groupId, (cur) => {
      const n = cur.numTournaments + 1;
      return {
        ...cur,
        numTournaments:    n,
        tournamentLabels:  [...cur.tournamentLabels, `T${n}`],
        rows: recalculate(cur.rows.map((r) => ({
          ...r,
          tournamentPoints: [...r.tournamentPoints, 0],
        }))),
      };
    });
  };

  const removeTournament = (groupId) => {
    setGrid(groupId, (cur) => {
      if (cur.numTournaments <= 1) return cur;
      const n = cur.numTournaments - 1;
      return {
        ...cur,
        numTournaments:   n,
        tournamentLabels: cur.tournamentLabels.slice(0, n),
        rows: recalculate(cur.rows.map((r) => ({
          ...r,
          tournamentPoints: r.tournamentPoints.slice(0, n),
        }))),
      };
    });
  };

  const renameTournament = (groupId, tIdx, label) => {
    setGrid(groupId, (cur) => {
      const labels = [...cur.tournamentLabels];
      labels[tIdx] = label;
      return { ...cur, tournamentLabels: labels };
    });
  };

  /* ════ add player row ════════════════════════ */
  const addPlayerRow = (groupId) => {
    setGrid(groupId, (cur) => {
      const blank = blankRow(tmpCounter++);
      blank.tournamentPoints = Array(cur.numTournaments).fill(0);
      return { ...cur, rows: [...cur.rows, blank] };
    });
  };

  /* ════ delete player row ═════════════════════ */
  const confirmDeleteRow = (groupId, row) => {
    setDelRowInfo({ groupId, tmpId: row._tmpId, dbId: row._dbId });
    setShowDelRow(true);
  };

  const handleDeleteRow = async () => {
    const { groupId, tmpId, dbId } = delRowInfo;
    if (dbId) {
      try {
        await axios.delete(`${process.env.REACT_APP_API_URL}/api/admin/deleteranking/${dbId}`);
      } catch (err) { return alert("Failed to delete"); }
    }
    setGrid(groupId, (cur) => ({
      ...cur,
      rows: recalculate(cur.rows.filter((r) => r._tmpId !== tmpId)),
    }));
    setShowDelRow(false);
  };

  /* ════ SAVE ALL ══════════════════════════════ */
  const saveAll = async (group) => {
    const grid = getGrid(group._id);
    const validRows = grid.rows.filter((r) => r.PlayerName.trim());
    if (validRows.length === 0) return alert("Please add at least one player name.");
    setSaving(true);
    try {
      const players = validRows.map((r) => ({
        Rank:              r.Rank,
        PlayerName:        r.PlayerName.trim(),
        Points:            r.Points,
        Club:              r.Club,
        City:              r.City,
        State:             r.State,
        PreviousRank:      r.PreviousRank || 0,
        TournamentsPlayed: r.TournamentsPlayed,
        Status:            r.Status,
        tournamentPoints:  r.tournamentPoints,
      }));

      // save tournament labels to the group too
      const fd = new FormData();
      fd.append("id", group._id);
      fd.append("TournamentLabels", JSON.stringify(grid.tournamentLabels));
      await axios.put(`${process.env.REACT_APP_API_URL}/api/admin/editrankinggroup`, fd,
        { headers: { "content-type": "multipart/form-data" } });

      const res = await axios.post(
        `${process.env.REACT_APP_API_URL}/api/admin/ranking/bulk`,
        { players, Year: group.Year, Category: group.Category },
        { headers: { "content-type": "application/json" } }
      );
      if (res.status === 200) {
        alert(`✅ ${validRows.length} players saved!`);
        setGrid(group._id, (cur) => ({
          ...cur,
          rows: cur.rows.map((r) => ({ ...r, _saved: true })),
        }));
        loadPlayersIntoGrid(group);
      }
    } catch (err) {
      alert(err?.response?.data?.msg || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  /* ════ GROUP CRUD ════════════════════════════ */
  const resetGroup = () => {
    setGTitle(""); setGTagline("Turn your childhood dream into reality");
    setGYear(thisYear); setGCategory(CATEGORIES[0]);
    setGImage(null); setGStatus("Active"); setGEditItem(null);
  };
  const handleGroupAdd = async () => {
    if (!gTitle || !gYear || !gCategory) return alert("Title, Year and Category are required.");
    try {
      const fd = new FormData();
      fd.append("Title", gTitle); fd.append("Tagline", gTagline);
      fd.append("Year", gYear);   fd.append("Category", gCategory);
      fd.append("Status", gStatus);
      if (gImage) fd.append("GroupImage", gImage);
      const res = await axios.post(`${process.env.REACT_APP_API_URL}/api/admin/rankinggroup`, fd,
        { headers: { "content-type": "multipart/form-data" } });
      if (res.status === 200) { alert(res.data.success); fetchGroups(); setShowGroupAdd(false); resetGroup(); }
    } catch (err) { alert(err?.response?.data?.msg || "Failed"); }
  };
  const openGroupEdit = (g) => {
    setGEditItem(g); setGTitle(g.Title ?? ""); setGTagline(g.Tagline ?? "");
    setGYear(g.Year ?? thisYear); setGCategory(g.Category ?? CATEGORIES[0]);
    setGStatus(g.Status ?? "Active"); setGImage(null); setShowGroupEdit(true);
  };
  const handleGroupEdit = async (e) => {
    e.preventDefault();
    try {
      const fd = new FormData();
      fd.append("id", gEditItem._id); fd.append("Title", gTitle);
      fd.append("Tagline", gTagline); fd.append("Year", gYear);
      fd.append("Category", gCategory); fd.append("Status", gStatus);
      if (gImage) fd.append("GroupImage", gImage);
      const res = await axios.put(`${process.env.REACT_APP_API_URL}/api/admin/editrankinggroup`, fd,
        { headers: { "content-type": "multipart/form-data" } });
      if (res.status === 200) { alert("Updated"); fetchGroups(); setShowGroupEdit(false); resetGroup(); }
    } catch (err) { alert(err?.response?.data?.msg || "Failed"); }
  };
  const handleGroupDel = async () => {
    try {
      await axios.delete(`${process.env.REACT_APP_API_URL}/api/admin/deleterankinggroup/${gDelId}`);
      alert("Deleted"); fetchGroups(); setShowGroupDel(false); setExpandedId(null);
    } catch (err) { alert(err?.response?.data?.msg || "Failed"); }
  };

  const GroupForm = (
    <div className="row g-3">
      <div className="col-md-12">
        <div className="do-sear">
          <label>Ranking Title <span style={{ color:"red" }}>*</span></label>
          <input type="text" className="vi_0" value={gTitle}
            placeholder="e.g. 2025 - CORPORATE RANKING"
            onChange={(e) => setGTitle(e.target.value)} />
        </div>
      </div>
      <div className="col-md-12">
        <div className="do-sear">
          <label>Tagline</label>
          <input type="text" className="vi_0" value={gTagline}
            placeholder="e.g. Turn your childhood dream into reality"
            onChange={(e) => setGTagline(e.target.value)} />
        </div>
      </div>
      <div className="col-md-6">
        <div className="do-sear">
          <label>Year <span style={{ color:"red" }}>*</span></label>
          <Form.Select className="vi_0" value={gYear} onChange={(e) => setGYear(e.target.value)}>
            {YEARS.map((y) => <option key={y} value={y}>{y}</option>)}
          </Form.Select>
        </div>
      </div>
      <div className="col-md-6">
        <div className="do-sear">
          <label>Category <span style={{ color:"red" }}>*</span></label>
          <Form.Select className="vi_0" value={gCategory} onChange={(e) => setGCategory(e.target.value)}>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </Form.Select>
        </div>
      </div>
      <div className="col-md-6">
        <div className="do-sear">
          <label>Status</label>
          <Form.Select className="vi_0" value={gStatus} onChange={(e) => setGStatus(e.target.value)}>
            <option value="Active">Active</option>
            <option value="Inactive">Inactive</option>
          </Form.Select>
        </div>
      </div>
      <div className="col-md-6">
        <div className="do-sear">
          <label>Cover Photo</label>
          <input type="file" className="vi_0" accept="image/*"
            onChange={(e) => setGImage(e.target.files[0] || null)} />
          <small style={{ color:"#888" }}>Photo shown on the ranking card</small>
        </div>
      </div>
    </div>
  );

  /* ════════════════ RENDER ════════════════════ */
  return (
    <div>
      <div className="customerhead p-2">

        {/* heading */}
        <div className="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-2">
          <h2 className="header-c" style={{ display:"flex", alignItems:"center", gap:10, margin:0 }}>
            <FaTrophy style={{ color:"#e31e24" }} /> Ranking Circuit
          </h2>
          <button className="admin-add-btn"
            onClick={() => { resetGroup(); setShowGroupAdd(true); }}>
            <FaPlus style={{ marginRight:6 }} /> New Ranking
          </button>
        </div>

        {/* info banner */}
        <div className="rk-admin-banner">
          <MdAutoAwesome style={{ fontSize:20, color:"#0b2fae", flexShrink:0 }} />
          <span>
            Fill in player names and tournament points — <strong>Rank & Total are calculated automatically</strong>.
            Add tournament columns as needed. Click <strong>Save Rankings</strong> when done.
          </span>
        </div>

        {/* empty */}
        {groups.length === 0 && (
          <div style={{ textAlign:"center", padding:"60px 20px", color:"#aaa" }}>
            <FaTrophy style={{ fontSize:44, display:"block", margin:"0 auto 12px", color:"#e0e4f0" }} />
            <p>No rankings yet. Click <strong>New Ranking</strong> to create one.</p>
          </div>
        )}

        {/* accordion */}
        <div style={{ display:"flex", flexDirection:"column", gap:16 }}>
          {groups.map((group) => {
            const isOpen = expandedId === group._id;
            const grid   = getGrid(group._id);
            const rows   = grid.rows;
            const nT     = grid.numTournaments;
            const labels = grid.tournamentLabels;
            const unsaved = rows.some((r) => !r._saved && r.PlayerName);

            return (
              <div key={group._id} className={`rk-admin-card${isOpen ? " open" : ""}`}>

                {/* header row */}
                <div className="rk-admin-card-header" onClick={() => toggleExpand(group)}>
                  <div style={{ width:60, height:46, borderRadius:7, overflow:"hidden",
                    flexShrink:0, background:"#eef2ff", display:"flex",
                    alignItems:"center", justifyContent:"center" }}>
                    {group.GroupImage ? (
                      <img src={`${process.env.REACT_APP_API_URL}/Rankings/${group.GroupImage}`}
                        style={{ width:"100%", height:"100%", objectFit:"cover" }} alt="" />
                    ) : <FaTrophy style={{ color:"#c5d0f5", fontSize:18 }} />}
                  </div>

                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontWeight:900, fontSize:15, color:"#031b77",
                      overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                      {group.Title}
                      {unsaved && <span style={{ background:"#fef3c7", color:"#92400e",
                        fontSize:11, fontWeight:700, borderRadius:20, padding:"2px 8px",
                        marginLeft:8 }}>Unsaved changes</span>}
                    </div>
                    <div style={{ fontSize:12, color:"#888" }}>{group.Tagline}</div>
                  </div>

                  <div style={{ display:"flex", gap:6, flexShrink:0, flexWrap:"wrap" }}>
                    {[
                      { v:group.Year,     bg:"#eef2ff", c:"#031b77" },
                      { v:group.Category, bg:"#f0f4ff", c:"#031b77" },
                      { v:group.Status,
                        bg:group.Status==="Active"?"#dcfce7":"#fee2e2",
                        c:group.Status==="Active"?"#16a34a":"#dc2626" },
                      { v:`${isOpen ? rows.length : "…"} players`,
                        bg:"#f5f5f5", c:"#666" },
                    ].map((b, i) => (
                      <span key={i} style={{ background:b.bg, color:b.c, borderRadius:20,
                        padding:"3px 10px", fontSize:11, fontWeight:700 }}>{b.v}</span>
                    ))}
                  </div>

                  <div style={{ display:"flex", gap:8, flexShrink:0 }}
                    onClick={(e) => e.stopPropagation()}>
                    <BiSolidEdit className="text-success" style={{ fontSize:18, cursor:"pointer" }}
                      onClick={() => openGroupEdit(group)} />
                    <AiFillDelete className="text-danger" style={{ fontSize:18, cursor:"pointer" }}
                      onClick={() => { setGDelId(group._id); setShowGroupDel(true); }} />
                  </div>

                  <div style={{ color:"#031b77", fontSize:16, flexShrink:0 }}>
                    {isOpen ? <FaChevronUp /> : <FaChevronDown />}
                  </div>
                </div>

                {/* ── expanded grid ────────────── */}
                {isOpen && (
                  <div style={{ padding:"18px 16px" }}>

                    {/* grid toolbar */}
                    <div className="rk-grid-toolbar">
                      <div style={{ display:"flex", gap:8, alignItems:"center", flexWrap:"wrap" }}>
                        <span style={{ fontSize:13, fontWeight:700, color:"#031b77" }}>
                          Tournaments:
                        </span>
                        <button className="rk-grid-btn rk-grid-btn-outline"
                          onClick={() => removeTournament(group._id)}
                          disabled={nT <= 1}>
                          − Remove
                        </button>
                        {labels.map((lbl, ti) => (
                          <input key={ti}
                            className="rk-tournament-label-input"
                            value={lbl}
                            style={{ width: Math.max(70, lbl.length * 9 + 20) }}
                            onChange={(e) => renameTournament(group._id, ti, e.target.value)}
                            title="Click to rename tournament"
                          />
                        ))}
                        <button className="rk-grid-btn rk-grid-btn-outline"
                          onClick={() => addTournament(group._id)}>
                          + Add
                        </button>
                      </div>

                      <div style={{ display:"flex", gap:8 }}>
                        <button className="rk-grid-btn rk-grid-btn-ghost"
                          onClick={() => addPlayerRow(group._id)}>
                          <FaUserPlus style={{ marginRight:4 }} /> Add Row
                        </button>
                        <button
                          className="rk-grid-btn rk-grid-btn-save"
                          onClick={() => saveAll(group)}
                          disabled={saving}>
                          <FaSave style={{ marginRight:5 }} />
                          {saving ? "Saving…" : "Save Rankings"}
                        </button>
                      </div>
                    </div>

                    {/* loading state */}
                    {gridLoading[group._id] ? (
                      <div style={{ textAlign:"center", padding:"32px", color:"#888" }}>
                        <div style={{ fontSize:24, marginBottom:8 }}>⏳</div>
                        <p style={{ margin:0, fontSize:14 }}>Loading players…</p>
                      </div>
                    ) : (
                    <>
                    {/* ── THE GRID ─────────────── */}
                    <div className="rk-grid-wrap">
                      <table className="rk-grid-table">
                        <thead>
                          <tr>
                            <th className="rk-th-rank">Rank</th>
                            <th className="rk-th-name">Player Name <span style={{color:"#f87171"}}>*</span></th>
                            <th className="rk-th-club">Club</th>
                            <th className="rk-th-club">City</th>
                            <th className="rk-th-state">State</th>
                            <th className="rk-th-prev">Prev Rank</th>
                            {labels.map((lbl, ti) => (
                              <th key={ti} className="rk-th-pts" style={{ background:"#0b2fae" }}>{lbl}</th>
                            ))}
                            <th className="rk-th-total">Total</th>
                            <th className="rk-th-status">Status</th>
                            <th className="rk-th-del"></th>
                          </tr>
                        </thead>
                        <tbody>
                          {rows.map((row, rowIdx) => {
                            const rankColor =
                              row.Rank === 1 ? "#B7860B" :
                              row.Rank === 2 ? "#607080" :
                              row.Rank === 3 ? "#8B5A2B" : "#031b77";

                            return (
                              <tr key={row._tmpId}
                                className={`rk-grid-row${row.Rank <= 3 && row.PlayerName ? " rk-top3" : ""}`}>

                                {/* RANK — auto */}
                                <td className="rk-td-rank">
                                  {row.PlayerName ? (
                                    <div style={{ display:"flex", alignItems:"center", justifyContent:"center", gap:4 }}>
                                      {row.Rank <= 3 && <FaMedal style={{ color:rankColor, fontSize:13 }} />}
                                      <span style={{ fontWeight:900, color:rankColor, fontSize:16 }}>
                                        {row.Rank}
                                      </span>
                                    </div>
                                  ) : <span style={{ color:"#ccc", textAlign:"center", display:"block" }}>—</span>}
                                </td>

                                {/* PLAYER NAME */}
                                <td className="rk-td-name">
                                  <input
                                    className="rk-cell-input rk-input-name"
                                    value={row.PlayerName}
                                    placeholder="Player name…"
                                    onChange={(e) => updateCell(group._id, row._tmpId, "PlayerName", e.target.value)}
                                  />
                                </td>

                                {/* CLUB */}
                                <td>
                                  <input className="rk-cell-input"
                                    value={row.Club}
                                    placeholder="Club / Academy"
                                    onChange={(e) => updateCell(group._id, row._tmpId, "Club", e.target.value)}
                                  />
                                </td>

                                {/* CITY */}
                                <td>
                                  <input className="rk-cell-input"
                                    value={row.City}
                                    placeholder="City"
                                    onChange={(e) => updateCell(group._id, row._tmpId, "City", e.target.value)}
                                  />
                                </td>

                                {/* STATE */}
                                <td>
                                  <input className="rk-cell-input"
                                    value={row.State}
                                    placeholder="State"
                                    onChange={(e) => updateCell(group._id, row._tmpId, "State", e.target.value)}
                                  />
                                </td>

                                {/* PREVIOUS RANK */}
                                <td>
                                  <input
                                    className="rk-cell-input rk-input-pts"
                                    type="number" min="0"
                                    value={row.PreviousRank || ""}
                                    placeholder="0"
                                    onChange={(e) => updateCell(group._id, row._tmpId, "PreviousRank", Number(e.target.value) || 0)}
                                  />
                                </td>

                                {/* TOURNAMENT POINTS — one cell per tournament */}
                                {labels.map((_, ti) => (
                                  <td key={ti} className="rk-td-pts">
                                    <input
                                      className="rk-cell-input rk-input-pts rk-pts-col"
                                      type="number"
                                      min="0"
                                      value={row.tournamentPoints[ti] || ""}
                                      placeholder="0"
                                      onChange={(e) =>
                                        updateTournamentPoint(group._id, row._tmpId, ti, e.target.value)
                                      }
                                    />
                                  </td>
                                ))}

                                {/* TOTAL — auto */}
                                <td className="rk-td-total">
                                  <span className="rk-total-chip"
                                    style={{
                                      background: row.Rank===1 ? "#B7860B" : row.Rank===2 ? "#607080" : row.Rank===3 ? "#8B5A2B" : "#031b77"
                                    }}>
                                    {row.Points.toLocaleString()}
                                  </span>
                                </td>

                                {/* STATUS */}
                                <td>
                                  <select
                                    className="rk-cell-input rk-select-status"
                                    value={row.Status}
                                    onChange={(e) => updateCell(group._id, row._tmpId, "Status", e.target.value)}>
                                    <option value="Active">Active</option>
                                    <option value="Inactive">Inactive</option>
                                  </select>
                                </td>

                                {/* DELETE ROW */}
                                <td className="rk-td-del">
                                  <AiFillDelete
                                    className="text-danger"
                                    style={{ cursor:"pointer", fontSize:16 }}
                                    onClick={() => confirmDeleteRow(group._id, row)}
                                  />
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>

                    {/* bottom save */}
                    <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginTop:14 }}>
                      <span style={{ fontSize:12.5, color:"#888" }}>
                        💡 Rank and Total auto-calculate as you type. Click <strong>Save Rankings</strong> to publish.
                      </span>
                      <button
                        className="rk-grid-btn rk-grid-btn-save"
                        onClick={() => saveAll(group)}
                        disabled={saving}>
                        <FaSave style={{ marginRight:5 }} />
                        {saving ? "Saving…" : `Save Rankings (${rows.filter(r => r.PlayerName).length} players)`}
                      </button>
                    </div>
                    </>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* ═══ GROUP MODALS ═══════════════════════ */}
        <Modal show={showGroupAdd} onHide={() => { setShowGroupAdd(false); resetGroup(); }}
          size="lg" style={{ zIndex:99999 }}>
          <Modal.Header closeButton>
            <Modal.Title style={{ color:"#031b77", fontWeight:800 }}>
              <FaPlus style={{ marginRight:8, color:"#e31e24" }} /> New Ranking
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>{GroupForm}</Modal.Body>
          <Modal.Footer>
            <Button variant="" className="modal-close-btn"
              onClick={() => { setShowGroupAdd(false); resetGroup(); }}>Close</Button>
            <Button variant="" className="modal-add-btn" onClick={handleGroupAdd}>Create</Button>
          </Modal.Footer>
        </Modal>

        <Modal show={showGroupEdit} onHide={() => { setShowGroupEdit(false); resetGroup(); }}
          size="lg" style={{ zIndex:99999 }}>
          <Modal.Header closeButton>
            <Modal.Title style={{ color:"#031b77", fontWeight:800 }}>
              <BiSolidEdit style={{ marginRight:8, color:"#22c55e" }} /> Edit Ranking
            </Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {gEditItem?.GroupImage && (
              <div className="mb-3 text-center">
                <Image src={`${process.env.REACT_APP_API_URL}/Rankings/${gEditItem.GroupImage}`}
                  style={{ width:180, height:110, objectFit:"cover", borderRadius:8 }} />
                <p style={{ fontSize:12, color:"#888", marginTop:4 }}>Current cover</p>
              </div>
            )}
            {GroupForm}
          </Modal.Body>
          <Modal.Footer>
            <Button variant="" className="modal-close-btn"
              onClick={() => { setShowGroupEdit(false); resetGroup(); }}>Close</Button>
            <Button variant="" className="modal-add-btn" onClick={handleGroupEdit}>Update</Button>
          </Modal.Footer>
        </Modal>

        <Modal show={showGroupDel} onHide={() => setShowGroupDel(false)} style={{ zIndex:99999 }}>
          <Modal.Header closeButton><Modal.Title>Warning</Modal.Title></Modal.Header>
          <Modal.Body>
            <p className="fs-5" style={{ color:"red" }}>Delete this ranking card?</p>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="" className="modal-close-btn" onClick={() => setShowGroupDel(false)}>Close</Button>
            <Button variant="" className="modal-add-btn" onClick={handleGroupDel}>Delete</Button>
          </Modal.Footer>
        </Modal>

        {/* delete row confirm */}
        <Modal show={showDelRow} onHide={() => setShowDelRow(false)} style={{ zIndex:99999 }}>
          <Modal.Header closeButton><Modal.Title>Remove player?</Modal.Title></Modal.Header>
          <Modal.Body>
            <p style={{ color:"red" }}>Remove this player row from the ranking?</p>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="" className="modal-close-btn" onClick={() => setShowDelRow(false)}>Cancel</Button>
            <Button variant="" className="modal-add-btn" onClick={handleDeleteRow}>Remove</Button>
          </Modal.Footer>
        </Modal>

      </div>
    </div>
  );
};

export default AdminRanking;
