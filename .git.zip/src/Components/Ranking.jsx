import { useEffect, useState } from "react";
import { Container } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import Aos from "aos";
import "aos/dist/aos.css";
import axios from "axios";
import { IoLogoWhatsapp } from "react-icons/io";
import { FaTrophy, FaArrowLeft } from "react-icons/fa";
import { GiShuttlecock } from "react-icons/gi";
import "../Styles/ranking.css";

const Ranking = () => {
  const navigate = useNavigate();
  const [groups,  setGroups]  = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Aos.init({ once: true });
    window.scroll(0, 0);
    fetchGroups();
  }, []);

  const fetchGroups = async () => {
    try {
      const res = await axios.get(
        `${process.env.REACT_APP_API_URL}/api/admin/activerankinggroups`
      );
      setGroups(Array.isArray(res?.data?.groups) ? res.data.groups : []);
    } catch {
      setGroups([]);
    } finally {
      setLoading(false);
    }
  };

  const goToDetail = (group) => {
    const cat = encodeURIComponent(group.Category);
    navigate(`/ranking/${group.Year}/${cat}`);
  };

  return (
    <div className="ranking-page">

      {/* Floating WhatsApp */}
      <div className="fixed-icon">
        <a href="https://wa.link/5s5pya" target="_blank" rel="noopener noreferrer"
          style={{ color: "unset", textDecoration: "none" }}>
          <span className="fixed-icon-rings" />
          <IoLogoWhatsapp style={{ color:"white", fontSize:"34px",
            display:"block", position:"relative", zIndex:4 }} />
        </a>
      </div>

      {/* ── Hero header ──────────────────────── */}
      <div className="rk-hero-header">
        <div className="rk-hero-inner" data-aos="fade-down" data-aos-duration="700">
          <GiShuttlecock className="rk-hero-shuttle" />
          <div>
            <h1 className="rk-hero-title">RANKING CIRCUIT</h1>
            <p className="rk-hero-sub">Official Shuttle Smash Player Rankings</p>
          </div>
          <GiShuttlecock className="rk-hero-shuttle rk-flip" />
        </div>
      </div>

      <Container>

        {/* loading */}
        {loading && (
          <div className="rk-center-msg">
            <GiShuttlecock className="rk-spin" />
            <p>Loading rankings…</p>
          </div>
        )}

        {/* no groups → coming soon */}
        {!loading && groups.length === 0 && (
          <div className="rk-coming" data-aos="fade-up" data-aos-duration="700">
            <div className="rk-cs-badge">
              <span className="rk-cs-ring" />
              <FaTrophy className="rk-cs-trophy" />
            </div>
            <span className="rk-cs-pill">RANKING CIRCUIT</span>
            <h1 className="rk-cs-title" aria-label="COMING SOON">
              {"COMING SOON".split("").map((ch, i) => (
                <span key={i}
                  className={`rk-letter${ch===" "?" rk-space":""}`}
                  style={{ animationDelay:`${i*0.07}s` }}>
                  {ch===" " ? "\u00A0" : ch}
                </span>
              ))}
            </h1>
            <p className="rk-cs-text">
              We're building the Shuttle Smash Ranking Circuit. Live player rankings,
              leaderboards and point tables are on the way. Stay tuned!
            </p>
            <div className="rk-cs-bar"><span className="rk-cs-fill" /></div>
            <button className="rk-cs-btn" onClick={() => navigate("/")}>
              <FaArrowLeft /> Back to Home
            </button>
          </div>
        )}

        {/* ranking group cards — exactly like spreetime */}
        {!loading && groups.length > 0 && (
          <div className="rk-groups">
            {groups.map((group, i) => (
              <div
                key={group._id}
                className="rk-group-card"
                data-aos="fade-up"
                data-aos-duration="700"
                data-aos-delay={i * 80}
              >
                {/* left — image */}
                <div className="rk-group-img-wrap">
                  {group.GroupImage ? (
                    <img
                      src={`${process.env.REACT_APP_API_URL}/Rankings/${group.GroupImage}`}
                      alt={group.Title}
                      className="rk-group-img"
                    />
                  ) : (
                    <div className="rk-group-img-placeholder">
                      <GiShuttlecock />
                    </div>
                  )}
                </div>

                {/* right — info */}
                <div className="rk-group-info">
                  <h2 className="rk-group-title">{group.Title}</h2>
                  <p className="rk-group-tagline">{group.Tagline}</p>
                  <button
                    className="rk-check-btn"
                    onClick={() => goToDetail(group)}
                  >
                    CHECK MY RANK
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

      </Container>
    </div>
  );
};

export default Ranking;
